<?php
require_once './modules/config.php';
require_once './modules/App.php';
require_once './modules/Controller.php';
require_once './modules/db_module.php';

$init = new App();
?>